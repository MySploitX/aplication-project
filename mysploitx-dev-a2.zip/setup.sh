#!/bin/bash

pkg update -y && pkg install apt -y && apt install wget -y && apt install git -y && apt install python2 -y && pip2 install requests && pip2 install pyyaml
chmod +x *